package assistedPractice4;



	public class practice3 {
	    public static int exponentialSearch(int[] arr, int target) {
	        if (arr[0] == target) {
	            return 0;
	        }
	      
	        int n = arr.length;
	        int i = 1;
	        while (i < n && arr[i] <= target) {
	            i *= 2;
	        }

	        return binarySearch(arr, target, i / 2, Math.min(i, n - 1));
	    }

	    private static int binarySearch(int[] arr, int target, int low, int high) {
	        if (high >= low) {
	            int mid = low + (high - low) / 2;

	            if (arr[mid] == target) {
	                return mid;
	            }

	            if (arr[mid] > target) {
	                return binarySearch(arr, target, low, mid - 1);
	            }

	            return binarySearch(arr, target, mid + 1, high);
	        }

	        return -1; // Element not found
	    }

	    public static void main(String[] args) {
	        int[] arr = {2, 5, 10, 15, 20, 25, 30, 35};
	        int target = 20;

	        int index = exponentialSearch(arr, target);
	        if (index != -1) {
	            System.out.println("Element found at index " + index);
	        } else {
	            System.out.println("Element not found in the array");
	        }
	    }
	}
