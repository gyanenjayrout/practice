package AssistedPractice1;


class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class practice_5 {
    public static void main(String[] args) {
        try {
            // some code that might throw an exception
            throwCustomException();
        } catch (CustomException e) {
            // handle the custom exception
            System.out.println("Custom Exception: " + e.getMessage());
        } finally {
            // code that runs regardless of whether an exception is thrown or not
            System.out.println("Finally block executed.");
        }
    }

    public static void throwCustomException() throws CustomException {
        // code that might throw a custom exception
        throw new CustomException("This is a custom exception.");
    }
}
