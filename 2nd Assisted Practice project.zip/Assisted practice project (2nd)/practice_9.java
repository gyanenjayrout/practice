package AssistedPractice1;


interface Animal {
    void move();
}

interface Mammal extends Animal {
    void feed();
}

interface Bird extends Animal {
    void fly();
}

class Bat implements Mammal, Bird {
    public void move() {
        System.out.println("Bat is crawling");
    }
    
    public void feed() {
        System.out.println("Bat is feeding milk to its young ones");
    }
    
    public void fly() {
        System.out.println("Bat is flying");
    }
}
public class practice_9 {
    public static void main(String[] args) {
        Bat bat = new Bat();
        bat.move(); // prints "Bat is crawling"
        bat.feed(); // prints "Bat is feeding milk to its young ones"
        bat.fly();  // prints "Bat is flying"
    }
}
