package AssistedPractice1;

import java.io.*;

public class practice_7 {
    public static void main(String[] args) {
        try {
            // Create a file
            File file = new File("example.txt");
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }

            // Write to a file
            FileWriter writer = new FileWriter(file);
            writer.write("This is an example text.");
            writer.close();

            // Read from a file
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            reader.close();

            // Update a file
            FileWriter updater = new FileWriter(file, true);
            updater.write("\nThis is an updated text.");
            updater.close();

            // Read from the updated file
            BufferedReader updaterReader = new BufferedReader(new FileReader(file));
            String updatedLine;
            while ((updatedLine = updaterReader.readLine()) != null) {
                System.out.println(updatedLine);
            }
            updaterReader.close();

            // Delete a file
            if (file.delete()) {
                System.out.println("File deleted: " + file.getName());
            } else {
                System.out.println("Failed to delete the file.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}
