package AssistedPractice1;


import java.util.Scanner;

public class practice_4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an integer: ");

        try {
            int number = scanner.nextInt();
            int result = 10 / number;
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Exception caught: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Unknown exception caught: " + e.getMessage());
        } finally {
            scanner.close();
            System.out.println("Program completed.");
        }
    }
}

