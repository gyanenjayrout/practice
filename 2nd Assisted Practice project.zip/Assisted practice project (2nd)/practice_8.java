package AssistedPractice1;


//The Class is the blueprint for creating objects
class Car {
 // Encapsulation: fields are private to ensure data integrity
 private String make;
 private String model;
 private int year;
 private int speed;

 // Constructor: initializes the object's state
 public Car(String make, String model, int year) {
     this.make = make;
     this.model = model;
     this.year = year;
     this.speed = 0;
 }

 // Encapsulation: getters and setters allow controlled access to fields
 public String getMake() {
     return make;
 }

 public void setMake(String make) {
     this.make = make;
 }

 public String getModel() {
     return model;
 }

 public void setModel(String model) {
     this.model = model;
 }

 public int getYear() {
     return year;
 }

 public void setYear(int year) {
     this.year = year;
 }

 // Abstraction: hides implementation details from the user
 public void accelerate() {
     speed += 10;
 }

 public void brake() {
     speed -= 10;
 }

 public int getSpeed() {
     return speed;
 }

 // Polymorphism: method overloading allows the same method name with different parameters
 public void printInfo() {
     System.out.println("Make: " + make + ", Model: " + model + ", Year: " + year);
 }

 public void printInfo(boolean includeSpeed) {
     if (includeSpeed) {
         System.out.println("Make: " + make + ", Model: " + model + ", Year: " + year + ", Speed: " + speed);
     } else {
         printInfo();
     }
 }
}

public class practice_8{
 public static void main(String[] args) {
     // Object is an instance of a class
     Car myCar = new Car("Toyota", "Camry", 2021);

     // Encapsulation: accessing fields through public methods
     System.out.println("Make: " + myCar.getMake() + ", Model: " + myCar.getModel() + ", Year: " + myCar.getYear());

     // Abstraction: using methods to manipulate the object's state
     myCar.accelerate();
     myCar.accelerate();
     myCar.brake();

     // Polymorphism: using overloaded methods
     myCar.printInfo(); // prints Make: Toyota, Model: Camry, Year: 2021
     myCar.printInfo(true); // prints Make: Toyota, Model: Camry, Year: 2021, Speed: 10
 }
}
