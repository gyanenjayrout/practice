package AssistedPractice1;

class practice_3 {
    int total_seats = 10;

    synchronized void bookSeat(int seats) {
        if (total_seats >= seats) {
            System.out.println(seats + " seats booked successfully");
            total_seats = total_seats - seats;
            System.out.println("Seats Left: " + total_seats);
        } else {
            System.out.println("Seats Can't be Booked");
            System.out.println("Seats left:" + total_seats);
        }
    }
}

class MovieBookApp extends Thread {
    static practice_3 b;
    int seats;

    public void run() {
        b.bookSeat(seats);
    }

    public static void main(String[] args) {
        b = new practice_3();
        MovieBookApp deepak = new MovieBookApp();
        deepak.seats = 7;
        deepak.start();
        MovieBookApp amit = new MovieBookApp();
        amit.seats = 6;
        amit.start();
    }
}
