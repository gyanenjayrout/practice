package AssistedPractice1;


	
	
	    public class practice_1 extends Thread {
	        public void run() {
	            System.out.println("MyThread is running.");
	        }

	        public static void main(String[] args) {
	        	practice_1 thread = new practice_1();
	            thread.start();
	        }
	    }



	
