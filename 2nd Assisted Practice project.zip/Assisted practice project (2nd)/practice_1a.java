package AssistedPractice1;


public class practice_1a implements Runnable {
    public void run() {
        System.out.println("MyRunnable is running.");
    }

    public static void main(String[] args) {
    	practice_1a runnable = new practice_1a();
        Thread thread = new Thread(runnable);
        thread.start();
    }
}
