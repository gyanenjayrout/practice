

//Validation of an Email ID .

package AssistedPractice;



import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class project_2 {

    public static boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." +
                            "[a-zA-Z0-9_+&*-]+)*@" +
                            "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        
        return matcher.matches();
    }
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        String email;
        do {
            System.out.print("Enter an email address: ");
            email = input.nextLine();
            
            if (isValidEmail(email)) {
                System.out.println("Valid email address!");
                break;
            } else {
                System.out.println("Invalid email address!");
            }
        } while(true);
    }
}

