package AssistedPractice;

//Writing a program in Java to verify implementations of methods and ways of calling a method   

public class practice_3 {
	// Method that takes a parameter and does not return a value (void)
	
	public void printmessage(String message)
	{
		System.out.println(message);
		
	}
	// Method that does not take a parameter and does not return a value (void)
    public void printMessage() {
        System.out.println("How You doing?");
    }

    //  Method that takes a parameter and returns a value (String)
    public String returnMessage(String message) {
        return "Your message is: " + message;
    }
    
    public static void main(String[] args) {
      practice_3 st = new practice_3();
      st.printmessage("hello");
      
      st.printMessage();
      System.out.println(st.returnMessage("am ! great"));
    }
}
