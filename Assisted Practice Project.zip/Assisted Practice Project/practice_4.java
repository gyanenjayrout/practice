package AssistedPractice;

//Writing a program in Java to verify the implementations of constructor types

public class practice_4 {
	private int value;
	
	public practice_4()
	{
		value=0;
	}
	
	// Constructor with one parameter
    public practice_4(int value) {
        this.value = value;
    }
    
 // Copy constructor
    public practice_4(practice_4 other) {
        this.value = other.value;
    }
    
    //getter method
    
    public int getValue() {
    	return value;
    }
    
    public static void main(String[] args) {
        // Create objects using the constructors
    	practice_4 obj1 = new practice_4();
    	practice_4 obj2 = new practice_4(5);
    	practice_4 obj3 = new practice_4(obj2);
    	
    	System.out.println("Object 1 value: " + obj1.getValue()); // 0
        System.out.println("Object 2 value: " + obj2.getValue()); // 5
        System.out.println("Object 3 value: " + obj3.getValue()); // 5

}
}