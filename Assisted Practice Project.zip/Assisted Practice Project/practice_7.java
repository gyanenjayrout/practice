package AssistedPractice;


//Writing a program in Java to verify the implementation of inner classes

public class practice_7 {

	    
	    private int outerVar = 10;

	    public void outerMethod() {
	        System.out.println("Outer Method");
	    }

	    // Inner class
	    class InnerClass {
	        private int innerVar = 20;

	        public void innerMethod() {
	            System.out.println("Inner Method");
	        }

	        public void accessOuterClass() {
	            System.out.println("Accessing outer variable: " + outerVar);
	            outerMethod();
	        }
	    }

	    public static void main(String[] args) {
	    	practice_7 outerObj = new practice_7();
	        InnerClass innerObj = outerObj.new InnerClass();

	        // Accessing inner class methods and variable
	        innerObj.innerMethod();
	        System.out.println("Inner variable: " + innerObj.innerVar);

	        // Accessing outer class methods and variable from inner class
	        innerObj.accessOuterClass();
	    }
	}


