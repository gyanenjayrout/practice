package AssistedPractice;

public class practice_9 {
   
	

	    public static void main(String[] args) {
	        int[] numbers = {1, 2, 3, 4, 5};

	        // Accessing elements of the array
	        System.out.println("The first element is: " + numbers[0]);
	        System.out.println("The third element is: " + numbers[2]);

	        // Modifying elements of the array
	        numbers[1] = 10;
	        System.out.println("The second element is now: " + numbers[1]);

	        // Looping through an array
	        for (int i = 0; i < numbers.length; i++) {
	            System.out.println("Element at index " + i + " is: " + numbers[i]);
	        }

	        // Multidimensional array
	        int[][] matrix = {
	            {1, 2, 3},
	            {4, 5, 6},
	            {7, 8, 9}
	        };
	        System.out.println("The element at row 1, column 2 is: " + matrix[1][2]);
	    }
	}


