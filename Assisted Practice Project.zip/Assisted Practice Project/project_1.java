package AssistedPractice;

//Creating an Arithmetic Calculator.

import java.util.Scanner;

public class project_1 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        double num1, num2, result = 0.0;
        char operator;
        boolean validInput = false;
        
        // Loop until valid input is entered
        while (!validInput) {
            System.out.print("Enter the first number: ");
            num1 = input.nextDouble();
            
            System.out.print("Enter the second number: ");
            num2 = input.nextDouble();
            
            System.out.print("Enter an operator (+, -, *, /,^): ");
            operator = input.next().charAt(0);
            
            switch(operator) {
                case '+':
                    result = num1 + num2;
                    validInput = true;
                    break;
                case '-':
                    result = num1 - num2;
                    validInput = true;
                    break;
                case '*':
                    result = num1 * num2;
                    validInput = true;
                    break;
                case '/':
                    if (num2 == 0) {
                        System.out.println("Error: Cannot divide by zero");
                    } else {
                        result = num1 / num2;
                        validInput = true;
                    }
                    break;
                case '%':
                    if (num2 == 0) {
                        System.out.println("Error: Cannot divide by zero");
                    } else {
                        result = num1 % num2;
                        validInput = true;
                    }
                    break;
                case '^':
                    result = Math.pow(num1, num2);
                    validInput = true;
                    break;
                default:
                    System.out.println("Error: Invalid operator");
            }
            
            if (validInput) {
                System.out.println(num1 + " " + operator + " " + num2 + " = " + result);
            } else {
                System.out.println("Please enter valid input.");
            }
        }
    }
}

