package AssistedPractice;

//Write a program to create strings and display the conversion of string to StringBuffer and StringBuilder.

public class practice_8 {
	

	    public static void main(String[] args) {
	        String str = "Hello, World!";

	        // Conversion to StringBuffer
	        StringBuffer stringBuffer = new StringBuffer(str);
	        System.out.println("StringBuffer: " + stringBuffer);

	        // Conversion to StringBuilder
	        StringBuilder stringBuilder = new StringBuilder(str);
	        System.out.println("StringBuilder: " + stringBuilder);
	    }
	}



