package AssistedPractice;

public class practice_8 {
	

	    public static void main(String[] args) {
	        String str = "Hello, World!";

	        // Conversion to StringBuffer
	        StringBuffer stringBuffer = new StringBuffer(str);
	        System.out.println("StringBuffer: " + stringBuffer);

	        // Conversion to StringBuilder
	        StringBuilder stringBuilder = new StringBuilder(str);
	        System.out.println("StringBuilder: " + stringBuilder);
	    }
	}



