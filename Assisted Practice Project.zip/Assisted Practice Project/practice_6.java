package AssistedPractice;

//Writing a program in Java to verify implementations of maps

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class practice_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		        // Create a HashMap
		        Map<String, Integer> hashMap = new HashMap<>();
		        hashMap.put("Alice", 25);
		        hashMap.put("Bob", 30);
		        hashMap.put("Charlie", 35);
		        hashMap.put("David", 40);

		        // Verify the HashMap
		        System.out.println("HashMap:");
		        System.out.println(hashMap.containsKey("Alice")); // true
		        System.out.println(hashMap.containsValue(30)); // true
		        System.out.println(hashMap.get("Charlie")); // 35
		        System.out.println(hashMap.size()); // 4

		        // Create a TreeMap
		        Map<String, Integer> treeMap = new TreeMap<>();
		        treeMap.put("Alice", 25);
		        treeMap.put("Bob", 30);
		        treeMap.put("Charlie", 35);
		        treeMap.put("David", 40);

		        // Verify the TreeMap
		        System.out.println("TreeMap:");
		        System.out.println(treeMap.containsKey("Alice")); // true
		        System.out.println(treeMap.containsValue(30)); // true
		        System.out.println(treeMap.get("Charlie")); // 35
		        System.out.println(treeMap.size()); // 4
		    }
		


	}


