package AssistedPractice;

 class school {
	
	public String subject;
	private int student_id;
	protected String student_name;
	
	public void setStudentId(int value) {
		student_id= value;
		
	}
	public int getStudentid()
	{
		return student_id;
	}
}

public class practice_2
{
	public static void main(String[] args) {
		
		school st  = new school();
		
		st.subject="math";
		st.student_name="akash";
		st.setStudentId(10);
		System.out.println(st.getStudentid());
		System.out.println(st.subject);
		System.out.println(st.student_name);
		
		
	}
}



