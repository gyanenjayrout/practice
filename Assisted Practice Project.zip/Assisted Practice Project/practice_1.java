package AssistedPractice;
//Writing a program in Java to implement implicit and explicit type casting
public class practice_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         
		// Implicit type casting (widening)
		int a=10;
		double b = a;
		System.out.println("Implicit type casting: " + a + " -> " + b);
		
		//Explicit type Casting (narrowing)
		
		double c = 10.5;
		int d = (int)c;
		System.out.println("Explicit type casting: " + c + " -> " + d);
	}

}
