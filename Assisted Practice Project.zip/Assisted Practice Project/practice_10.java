package AssistedPractice;

//Writing a program in Java to verify implementations of regular expressions

import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class practice_10 {
          public static void main(String[] args) {
	        String input = "The quick brown fox jumps over the lazy dog";
	        String regex = "(?i)the.*?dog";

	        // Creating a pattern object
	        Pattern pattern = Pattern.compile(regex);

	        // Creating a matcher object
	        Matcher matcher = pattern.matcher(input);

	        // Finding matches
	        while (matcher.find()) {
	            System.out.println("Match found at index " + matcher.start() + ": " + matcher.group());
	        }
	    }
	}


