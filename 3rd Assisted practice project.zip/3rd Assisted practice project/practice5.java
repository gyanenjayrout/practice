package AssistedPractice3;


public class practice5 {
    private Node head;

    private class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
        }
    }

    public void delete(int key) {
        if (head == null) {
            return;
        }
        if (head.data == key) {
            head = head.next;
            return;
        }
        Node curr = head;
        while (curr.next != null) {
            if (curr.next.data == key) {
                curr.next = curr.next.next;
                return;
            }
            curr = curr.next;
        }
    }

    public void add(int data) {
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
    }

    public void print() {
        Node curr = head;
        while (curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        practice5 list = new practice5();
        list.add(3);
        list.add(7);
        list.add(4);
        list.add(7);
        list.add(9);
        list.print(); // prints "9 7 4 7 3"
        list.delete(7);
        list.print(); // prints "9 4 7 3"
    }
}

