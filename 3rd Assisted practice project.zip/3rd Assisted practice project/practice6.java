package AssistedPractice3;



public class practice6 {
    private Node head;

    private class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
        }
    }

    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            newNode.next = head;
            return;
        }
        Node curr = head;
        while (curr.next != head && curr.next.data < data) {
            curr = curr.next;
        }
        newNode.next = curr.next;
        curr.next = newNode;
        if (newNode.data < head.data) {
            head = newNode;
        }
    }

    public void print() {
        if (head == null) {
            return;
        }
        Node curr = head;
        do {
            System.out.print(curr.data + " ");
            curr = curr.next;
        } while (curr != head);
        System.out.println();
    }

    public static void main(String[] args) {
        practice6 list = new practice6();
        list.insert(2);
        list.insert(4);
        list.insert(7);
        list.insert(5);
        list.print(); // prints "2 4 5 7"
    }
}
