package AssistedPractice3;


import java.util.Scanner;

public class practice3 {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the number of elements: ");
        int n = input.nextInt();
        int[] arr = new int[n];
        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            arr[i] = input.nextInt();
        }
        System.out.print("Enter the lower limit of the range: ");
        int L = input.nextInt();
        System.out.print("Enter the upper limit of the range: ");
        int R = input.nextInt();
        int sum = findSumInRange(arr, L, R);
        System.out.println("The sum of elements in the range of [" + L + ", " + R + "] is: " + sum);
    }
    
    public static int findSumInRange(int[] arr, int L, int R) {
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }
        return sum;
    }
}

