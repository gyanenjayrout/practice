package AssistedPractice3;


public class practice7 {
    private Node head;
    private Node tail;
    
    // Inner class to represent a node
    private class Node {
        int data;
        Node prev;
        Node next;
        
        Node(int data) {
            this.data = data;
        }
    }
    
    // Method to add a new node at the end of the list
    public void add(int data) {
        Node newNode = new Node(data);
        
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }
    
    // Method to traverse the list in forward direction
    public void traverseForward() {
        if (head == null) {
            return;
        }
        
        Node current = head;
        
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        
        System.out.println();
    }
    
    // Method to traverse the list in backward direction
    public void traverseBackward() {
        if (tail == null) {
            return;
        }
        
        Node current = tail;
        
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        
        System.out.println();
    }
    
    public static void main(String[] args) {
        practice7 list = new practice7();
        
        // Add nodes to the list
        list.add(5);
        list.add(2);
        list.add(7);
        list.add(1);
        list.add(8);
        
        // Traverse the list in forward and backward directions
        list.traverseForward(); // Output: 5 2 7 1 8
        list.traverseBackward(); // Output: 8 1 7 2 5
    }
}
