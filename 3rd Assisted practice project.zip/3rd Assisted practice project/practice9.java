package AssistedPractice3;



import java.util.LinkedList;
import java.util.Queue;

public class practice9 {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        // Add elements to the queue
        queue.add(10);
        queue.add(20);
        queue.add(30);
        queue.add(40);

        // Remove and print the head element
        int headElement = queue.remove();
        System.out.println("Removed element: " + headElement);

        // Peek at the head element without removing it
        int peekElement = queue.peek();
        System.out.println("Peeked element: " + peekElement);

        // Add a new element to the end of the queue
        queue.add(50);

        // Print the queue contents
        System.out.println("Queue contents: " + queue);

        // Remove a specific element from the queue
        queue.remove(20);

        // Print the queue contents again
        System.out.println("Queue contents after removing 20: " + queue);
    }
}
