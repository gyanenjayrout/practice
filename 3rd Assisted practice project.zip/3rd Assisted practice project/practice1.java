package AssistedPractice3;

public class practice1 {
	public static void main(String[] args) {
	int arr[]= {1,2,3,4,5,6,7,8,9,10};
	int n =arr.length;
	int k =5;
	// Print the original array
	 System.out.println("Original array:");
     for (int i = 0; i < n; i++) {
         System.out.print(arr[i] + " ");
     }

    
 // Perform the right rotation
    
    for(int i=0;i<k;i++)
    {
    	int temp = arr[n-1]; // Store the last element
    	for(int j=n-1;j>0;j--)
    	{
    		arr[j]=arr[j-1];// Shift all elements to the right
    	}
    	arr[0]=temp; // Set the first element as the last element
    }
	
	 // Print the rotated array
    System.out.println("\nRotated array:");
    for (int i = 0; i < n; i++) {
        System.out.print(arr[i] + " ");
    }
	}

}
