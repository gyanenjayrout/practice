package AssistedPractice3;


import java.util.Stack;

public class practice8 {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();

        // Push elements onto the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);

        // Pop and print the top element
        int topElement = stack.pop();
        System.out.println("Popped element: " + topElement);

        // Peek at the top element without removing it
        int peekElement = stack.peek();
        System.out.println("Peeked element: " + peekElement);

        // Push a new element onto the stack
        stack.push(50);

        // Print the stack contents
        System.out.println("Stack contents: " + stack);

        // Remove a specific element from the stack
        stack.removeElement(20);

        // Print the stack contents again
        System.out.println("Stack contents after removing 20: " + stack);
    }
}
