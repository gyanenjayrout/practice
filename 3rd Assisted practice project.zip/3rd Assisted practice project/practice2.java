package AssistedPractice3;


import java.util.Arrays;

public class practice2 {
    
    public static void main(String[] args) {
        int[] list = {12, 7, 5, 23, 67, 8, 13, 21};
        int fourthSmallest = findFourthSmallest(list);
        System.out.println("The fourth smallest element is: " + fourthSmallest);
    }
    
    public static int findFourthSmallest(int[] list) {
        if (list.length < 4) {
            throw new IllegalArgumentException("List should contain at least 4 elements");
        }
        int[] copy = Arrays.copyOf(list, list.length);
        Arrays.sort(copy);
        return copy[3];
    }
}
